<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return redirect('/login');
});
Route::get('logout', 'HomeController@logout');
Auth::routes();
Route::get('/home', 'HomeController@index');
Route::get('/property/add', 'HomeController@addProperty');

Route::group(['middleware' => 'web'], function()
{

});

Auth::routes();

Route::get('/home', 'HomeController@index');
Route::get('/get_tenants/payment','HomeController@paymentstatistics');
Route::get('/get_payment/statistics','HomeController@paymentMethosStats');
Route::get('/account/settings','HomeController@settings');
Route::post('/provider/update/{id}','HomeController@settings');
Route::get('message/sent/items','MessageController@index');
Route::any('messages/sent/fetch_all','MessageController@fetchSent');

