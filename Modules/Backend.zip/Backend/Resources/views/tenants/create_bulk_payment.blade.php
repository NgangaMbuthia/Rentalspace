<?php 
use App\Helpers\Helper;
?>

@extends('layout.wizard')



@section('breadcrumb')
<ol class="breadcrumb pull-left">
       <li><a href="<?=url('/home')?>">Home</a></li>
        
        <li><a href="<?=url()->current();?>"></span>Bulk Payment</a></li>
        <li class="active">Bulk </li>
</ol>
<ul class="breadcrumb-elements">
              <li><a href="#"><i class="icon-comment-discussion position-left"></i> Support</a></li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <i class="icon-gear position-left"></i>
                  Settings
                  <span class="caret"></span>
                </a>

                <ul class="dropdown-menu dropdown-menu-right">
                  <li><a href="<?=url('/account/settings')?>"><i class="icon-user-lock"></i> Account security</a></li>
                  <li><a href="<?=url('/backend/property/statistics')?>"><i class="icon-statistics"></i> Analytics</a></li>
                  <li><a href="<?=url('/account/settings')?>"><i class="icon-accessibility"></i> Accessibility</a></li>
                  <li class="divider"></li>
                  <li><a href="<?=url('/account/settings')?>"><i class="icon-gear"></i> All settings</a></li>
                </ul>
              </li>
            </ul>
@stop

@section('content')
            

             <div class="panel panel-white">
                <div class="panel-heading">
                  <h6 class="panel-title"><i class="glyphicon glyphicon-list position-left"></i>Bulk Payments</h6>
                </div>
                
              <div class="panel-body">

                <div class="col-md-4 form-group">
                  <label>Property</label>
                  <select name="property" class="form-control" id="property">
                    <option value="">--Select Property---</option>
                       <?php foreach($properties as $proporty):?>
                           <option value="<?=$proporty->id;?>"><?=$proporty->title;?></option>
                       <?php endforeach;?>
                  </select>
                  
                </div>
                 <div class="clearfix"></div>
                <div class="row">
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                      <thead>
                        <tr class="info">
                          <th>TenantName</th>
                          <th>Space</th>
                          <th>InvoiceNumber</th>
                          <th>InvoiceAmount</th>
                          <th>AmountPaid</th>
                          <th>PaymentMethod</th>
                          <th>TransactionNumber</th>
                          <th>TransactionDate</th>
                        </tr>
                      </thead>
                      <tbody id="property-body">
                        
                      </tbody>
                      
                    </table>
                    
                  </div>
                  
                </div>

              

              </div>

              </div>

              @stop
              @push('scripts')
              <script type="text/javascript">
                 $("#property").on("change",function(e){
                   var property=$(this).val();
                    if(property.length>0)
                    {
                     var url="<?=url('/backend/make/bulkloadTenants')?>/"+property;
                      $.get(url,function(data){
                        $("#property-body").html(data);


                      })
                    }

                 })
              </script>


              @endpush

