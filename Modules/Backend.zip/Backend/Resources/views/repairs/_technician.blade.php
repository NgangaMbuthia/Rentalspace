<div class="row">
<div class="col-md-5">
<div class="form-group">
                                           
                                            <img class="img-responsive gallery" src="{{asset('/assets/images/k.png')}}" alt="" style="border-radius:5%;" id="passport" style="height:220px;width:170px;">
                                        </div>
	
</div>
<div class="col-md-7">
<table class="table table-bordered">
<tr class="success">
<th colspan="2" class="text-center">General Details</th>
	
</tr>
<tr><td>Name</td><td>Technician Technician</td></tr>
<tr><td>Email Address</td><td>email@email</td></tr>
<tr><td>Postal Address</td><td>4566-0100</td></tr>
<tr><td>Field</td><td>Electricity Matters</td></tr>
<tr><td>No of Project</td><td>56</td></tr>
<tr><td>Amount Paid</td><td>560</td></tr>
	

</table>
	
</div>

	

</div>
<div class="row ">
<div class="col-md-12">
<button type="button" class="btn btn-default btn-xs heading-btn"><i class="icon-envelope position-left"></i> Email</button>
  &nbsp;&nbsp;&nbsp;<button type="button" class="btn btn-default btn-xs heading-btn"><i class="icon-user position-left"></i> Full Profile</button>

  </div>
                
             
	
</div>