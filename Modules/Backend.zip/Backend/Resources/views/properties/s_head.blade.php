<div class="container-detached">
            <div class="content-detached">

              <!-- Invoice grid options -->
              <div class="navbar navbar-default navbar-xs navbar-component">
                <ul class="nav navbar-nav no-border visible-xs-block">
                  <li><a class="text-center collapsed" data-toggle="collapse" data-target="#navbar-filter"><i class="icon-menu7"></i></a></li>
                </ul>

                <div class="navbar-collapse collapse" id="navbar-filter">
                  
                  <ul class="nav navbar-nav">

                     
                   

                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-sort-amount-desc position-left"></i>Templates <span class="caret"></span></a>
                      <ul class="dropdown-menu">
                        <li><a href="<?=url('/backend/templates/create')?>"><span class="icon-googleplus5"></span> &nbsp;&nbsp;Create New</a></li>

                        <li><a href="<?=url('/backend/templates/index')?>"><span class="icon-list"></span> &nbsp;&nbsp;Available Templates</a></li>

                        
             
                       
                       
                      </ul>
                    </li>
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-delicious position-left"></i> Spaces<span class="caret"></span></a>
                      <ul class="dropdown-menu">
                        
                        
                        <li><a href="<?=url('/backend/space/add')?>">Create New</a></li>
                        <li><a href="<?=url('/backend/space/listView')?>">All Spaces/Units</a></li>
                        <li><a href="<?=url('/backend/space/listView?status=Occupied')?>">Occupied Spaces/Units</a></li>
                        <li><a href="<?=url('/backend/space/listView?status=Free')?>">Free Spaces/Units</a></li>
                         <li><a href="<?=url('/backend/space/listView?status=OnNotice')?>">On Notice Spaces/Units</a></li>
                        
                       
                      </ul>
                    </li>

                   
                   

                   
                     
                     <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-graph position-left"></i>statistic<span class="caret"></span></a>
                      <ul class="dropdown-menu">
                        <li><a href="<?=url('/backend/property/spaces/statistics')?>">Space/Unit Statistics</a></li>
                        <li><a href="<?=url('/backend/property/statistics/'.date('Y'))?>">Property Payments</a></li>
                        <li><a href="<?=url('/backend/property/repairs/statistics/'.date('Y'))?>">Property Repairs</a></li>
                       
                        
                       
                      </ul>
                    </li>

                   
                   
                    
                    
                     
                  </ul>

                  <div class="navbar-right">
                    <p class="navbar-text"></p>
                    <ul class="nav navbar-nav">
                      <li class="active"><a href="#"><i class="icon-sort-alpha-asc position-left"></i> Asc</a></li>
                      <li><a href="#"><i class="icon-sort-alpha-desc position-left"></i> Desc</a></li>

                    </ul>
                  </div>

                </div>

                
              </div>
              <!-- /invoice grid options -->

  </div>