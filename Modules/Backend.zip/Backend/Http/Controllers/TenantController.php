<?php

namespace Modules\Backend\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller ;
use Entrust;
use App\User;
use Modules\Backend\Entities\Space;
use Modules\Backend\Entities\Tenant;
use Modules\Backend\Entities\TenantPayment;
use Modules\Backend\Entities\Property;
use Modules\Backend\Base\TenantPdf;
use Auth;
use Modules\UserManagement\Entities\Role;
use Modules\UserManagement\Entities\Profile;
use DB;
use App\Messaging;
use App\Events\UserRegisterEvent;
use Session;
use App\Helpers\Helper;
use Modules\Backend\Entities\Agent;
use Modules\Backend\Entities\Deposit;
use Modules\Backend\Entities\EmergencyContact;
use Modules\Backend\Entities\TenantsOccupant;
use Modules\Backend\Entities\Student;
use Modules\Backend\Entities\Employer;
use Modules\Backend\Entities\Possession;
use Modules\Backend\Entities\TenantCharges;
use Modules\Backend\Entities\Invoice;
use Illuminate\Support\Facades\Input;
use Modules\Backend\Entities\Repair;
use Modules\Backend\Reports\Receipt;
use Redirect;
use Excel;
use Modules\Backend\Reports\InvoicePDf;
use Yajra\Datatables\Datatables;
use Illuminate\Support\Str;
use Illuminate\Support\Collection;
use Modules\Supplier\Entities\Supplier;
use Modules\Backend\Entities\Category;
use Modules\Backend\Entities\AdditionCharge;
use Modules\Tenants\Entities\SubmittedPayment;
use App\Http\Middleware\AccountSetUp;
use Modules\Backend\Entities\InvoiceComponent;
use Modules\Backend\Entities\InvoiceItem;
use Modules\Backend\Entities\Payment;
use Modules\Backend\Base\Import;
class TenantController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Response
     */

       public function __construct()
    {
        $this->middleware('auth');
        $this->middleware(AccountSetUp::class);

    }


    public function dashboard(){
      $data['page_title']="Tenants Dashboard";
      $data['tenant_count']=Tenant::where(['provider_id'=>Auth::User()->getProvider->id])->count();
      return view('backend::tenants.dashboard',$data);

    }

    public function getSystemCharges()
    {
      if(Entrust::hasRole("Provider") || Entrust::hasRole("Agent") || Entrust::hasRole("Admin")){
            $data['page_title']="Utility Settings";
             $data['system_currency']=config('app.system_currency');
              return view('backend::system_charges',$data);


        }else{
            return view("forbidden");
        }
    }
    public function index()
    {
        return view('backend::index');
    }


    public function importTenants(Request $request)
    {

       if(Entrust::hasRole("Provider")|| Entrust::hasRole("Agent"))
        {

           if($request->isMethod("post"))
           {

            $data=$request->all();

               $file = $request->file('file_name');
                $filePath = $file->getPathName();

                 $array=[]; 
                    \Excel::load($filePath, function($reader) {
          $results = $reader->get()->toArray();
        
          
             foreach($results as $result)
             {\DB::beginTransaction();
                  
                    dd($result);
                   $name=$result['tenant_full_name'];
                   $email=$result['tenant_email_address'];
                   $idnumber=$result['tenant_id_number'];
                   $telephone=$result['tenant_id_number'];
                   $space_id=$result['spaceid'];
                   $rent=doubleval($result['rent']);
                   $deposit=doubleval($result['deposit']);
                   $baance=doubleval($result['balance']);
                $user=Import::createExcelUser($result);
                  if($user)
                  {
                    $tenant=Import::createTenant($user,$result);
                  }
                
                  
               

                  \DB::commit();
                

             }$count=0;
              });
                Session::flash("success_msg","Tenants Imported Successfully");
                return redirect()->back();
           }
           $data['page_title']="Import Tenants";
         $data['properties']=Property::where(['provider_id'=>auth::user()->getProvider->id])->get();
           $data['url']=url()->current();

             return view('backend::tenants.import',$data);



        }else{
          return view("forbidden");
        }

    }
    public function getPendingInvoices($user_id,$space_id)
    {
      $models=Invoice::where(['issued_to'=>$user_id,'space_id'=>$space_id,'status'=>"Pending"])->get();
       return $models;

    }

    public function loadTenants($id)
    {
       $models=Tenant::join('spaces','spaces.id','=','tenants.space_id')
              ->join('users','users.id','=','tenants.user_id')
              ->where('spaces.property_id',$id)
              ->where('spaces.status','Occupied')
              ->select('tenants.id','spaces.number','users.name','users.id as user_id','spaces.id as space_id')
              ->get();

          foreach($models as $model)
          {
            $pendings=$this->getPendingInvoices($model->user_id,$model->space_id);

             $html='<tr>

               <td>'.$model->name.'</td>
               <td>'.$model->number.'</td>
               <td><select name="invoiceNumber[]" required>';
                foreach($pendings as $pending):

          $html.='<option value="">---InvoiceNumber--</option>
          <option value="'.$pending->id.'">'.$pending->invoice_number.'</option>';
            endforeach;
            $html.='</select><td>




             </tr>';

             echo $html;



              
            /*echo '<tr>
              <td>'.$model->name.'</td>
               <td>'.$model->number.'</td>

                <td><select>'; foreach($pendings as $pend):

                '
                  <option>A</option>

                  '.endforeach;.'

                </select></td>

              </tr>';*/


          }



    }

    public function getTemplate()
    {
      $id=$_GET['property_id'];
      $models=Space::where(['property_id'=>$id,'status'=>"Free"])->get();
       $format="Xls";
       $oreintation="landscape";
         Excel::create('TenantImport', function($excel) use($oreintation,$format,$models) {
          $excel->sheet('Sheet1', function($sheet) use($oreintation,$format,$models) {
         
          
                $arr =array();
                foreach($models as $model) {

                  
  $data =array($model->floor,$model->number,$model->id,
                               
                     );
                    array_push($arr, $data);
                    }
               $sheet->fromArray($arr,null,'A1',false,false)->prependRow(array(
                       'Floor','Unit','SpaceID','Tenant Full Name',"Tenant Email Address","Tenant ID Number","Tenant Telephone","Rent","Deposit","Balance"
                    )
                );
                
                $sheet->row(1,function($row){
                    $row->setFont(array(
                        'family'     => 'Calibri',
                        'bold'       =>  true
                    ));});

                $sheet->setOrientation($oreintation);

$sheet->getProtection()->setPassword('password');
$sheet->getProtection()->setSheet(true);
$sheet->getStyle('D1:J100')->getProtection()->setLocked(\PHPExcel_Style_Protection::PROTECTION_UNPROTECTED);
$sheet->getColumnDimension('C')->setVisible(false);

 

                 });

        })->export($format);
    }

    public function downloadTemplate()
    {
      $data['properties']=Property::where(['provider_id'=>auth::user()->getProvider->id])->get();
       return view('backend::tenants.template',$data);
    }

    public function submittedPayments()
    {
       if(Entrust::hasRole("Provider") || Entrust::hasRole("Agent"))
        {
          $data['page_title']="Sumitted Payment";
          return view('backend::tenants.submitted_payment',$data);

        }else{
          return view("forbidden");
        }
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        
         if(Entrust::hasRole("Provider") || Entrust::hasRole("Agent")){
          $data['page_title']="Tenant Management";
          $models=Property::where(['provider_id'=>Auth::User()->getProvider->id])->get();
          $data['properties']=$models;
          $data['charges']=InvoiceComponent::where(['type'=>'Occurance'])->get();

        
          return view('backend::tenants.create',$data);



         }else{
          return view("forbidden");
         }
         
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function storeTenants(Request $request)
    {
         
         
         $this->validate($request,[
            'property_id'=>'required|integer',
            'space_id'=>'required|integer',
            'name'=>'required',
            'id_number'=>'required',
            'phone'=>'required',
            'postal_address'=>'required',
            'expected_end_date'=>'date|required',
            'expected_end_date'=>'date|required',
            'email'=>'required|email',
            'charge'=>'required'
            ]);

         $data=$request->all();

          try{

    DB::beginTransaction();
    
     $user=User::where(['email'=>$data['email']])->first();
     if(!$user)
     {
      $user=$this->createUser($data);
     }
    
     $tenant=$this->createTenant($user,$data);
      
         DB::commit();
      Session::flash('success_msg','Tenant added successfully');
      return redirect()->back();
    }catch(\Exception $e)
     {
      Helper::sendEmailToSupport($e);
      Session::flash("danger_msg","Error occured while adding Tenant");
        return redirect()->back();
             
      }
  
      }

      public function createUser($data)
      {
        $user=new User();
        $user->name=$data['name'];
        $user->email=$data['email'];
        $user->password=$data['id_number'];
        $user->verification_code=str_random(8);
        $user->confirmed_at=date('Y-m-d H:i:s');
        $user->provider="Manual";
        
          if($user->save())
          {
            $this->assignTenantRole($user);
            $profile=$this->createProfile($user,$data);
            return $user;
          }else{
            return false;
          }
          
       }

      public function assignTenantRole($user)
      {
         try{
          $test=$this->verifyRole($user);
          $user->roles()->attach($test);


         }catch(\Exception $e)
          {
            Helper::sendEmailToSupport($e);
            return false;
          }
      }

      public function payMyInvoices($id,Request $request){
        $model=Invoice::find($id);
         if(!$model)
        {
          return "<h4 style='color:red;'>Resource Not Found</h4>";
        }

         if($request->isMethod("post"))
         {
          $this->validate($request,[
        'reference_number'=>'required|unique:tenant_payments',
        'payment_mode'=>'required|string',
        'credit'=>'required|integer',
        'transaction_date'=>'required|date',
        'description'=>'required'
        ]);
    $data=$request->all();
    $space=$model->space;
    $property=$space->property;


     $tenant=Tenant::where(['space_id'=>$space->id])->latest('id')->first();
      $invoice=$model;
     if($tenant):
      
   $payment_data=array('provider_id'=>$tenant->provider_id,
                        'space_id'=>$space->id,
                        'invoice_id'=>$invoice->id,
                        'reference_number'=>strtoupper($data['reference_number']),
                        'credit'=>0,
                        'debit'=>$data['credit'],
                        'description'=>$data['description'],
                        'payment_mode'=>$data['payment_mode'],
                        'type'=>$data['payment_type'],
                        'transaction_date'=>date('Y-m-d',strtotime($data['transaction_date'])),
                        'system_transaction_number'=>str_random(8),
                        'year'=>date('Y'),
                        'month'=>date('m'),
                        'fee_charges'=>0,
                        'tenant_id'=>$tenant->id,
                        );
       
    $user=$model->user;
    $name=$user->name;
    $phone=$user->profile->telephone;
    $year=date('Y',strtotime($model->issue_date));
    $month=date('F',strtotime($model->issue_date));
  $model=TenantPayment::create($payment_data);
      if($model){
        $invoice->status="Paid";
        $invoice->save();
      }

      $message=$body="Dear ".$name." we have received your payment  of ".$model->amount." ,for ".$year.",".$month." Your Ref Number for this payment incase of any query is ".strtoupper($data['reference_number']).". Thank you";

     
          $message=new Messaging();
           $message->receiver_id=$user->id;
           $message->sender_id=Auth::User()->id;
           $message->subject="Payment Acknowledgement";
           $message->content=$body;
           $message->flag="message";
           $message->key=strtoupper(str_random(8));
           $message->save();
          //$this->sendEmail($model);
    Session::flash('success_msg','Payment Saved Successfully');
    return redirect()->back();

     else:

    return redirec()->back()->withErrors("Tenant Specified Not Found ");

    endif;
     
     
     
         }







        $data['model']=$model;
         $data['url']=url()->current();
        return view('backend::tenants.invoice_pay',$data);

      }

     public function createTenantCharges($tenant,$data)
     {
      try{
        $charge_name=$data['charge'];
        $amount=$data['amount'];
        $total=0;$deposit=0;
        foreach($charge_name as $key=>$value)
          { 
            $mod=new TenantCharges();
            $mod->tenant_id=$tenant->id;
            $mod->charge_name=$charge_name[$key];
             if($mod->charge_name=="Deposit");
             {
              $deposit=$amount[$key];
              $this->createDeposit($tenant,$amount[$key]);
             }
              if(isset($amount[$key]) && strlen($amount[$key])>0){
               $mod->amount=$amount[$key];
              }else{
               $mod->amount=0;
              }
            $mod->effective_from=$data['entry_date'];
            $mod->status="Active";
            $total=$total+$amount[$key];
            $mod->save();
          }
        return true;

      }catch(\Exception $e)
       {
         
         Helper::sendEmailToSupport($e);
         return false;
       }

     }

public function CreditTenantAccount($tenant,$invoice)
{
  try{
      $system_ref=str_random(7);
      $payment=new TenantPayment();
      $payment->tenant_id=$tenant->id;
      $payment->payment_mode="BankSlip";
      $payment->reference_number=strtoupper(str_random(13));
      $payment->type="Intail Payment";
      $payment->space_id=$tenant->space_id;
      $payment->provider_id=$tenant->provider_id;
      $payment->debit=0;
      $payment->credit=$invoice->amount;
      $payment->month=date("M");
      $payment->year=date('Y');
      $payment->fee_charges=0;
       if(isset($invoice)){
        $payment->invoice_id=$invoice->id;
       }
       $payment->transaction_date=date('Y-m-d');
       $payment->system_transaction_number=$system_ref;
       $payment->description='Being New Payment For The Space + Deposit';
       $payment->save();
      return $payment;
  }catch(\Exception $e)
   {
     Helper::sendEmailToSupport($e);
     return false;

   }

}

  public function createTenantFirstInvoice($tenant)
  {
          $amount=($tenant->charges)?$tenant->charges->sum('amount'):0;
          $invoice=new Invoice();
          $invoice->provider_id=Auth::User()->getProvider->id;
          $invoice->issued_to=$tenant->user_id;
          $invoice->space_id=$tenant->space_id;
          $invoice->issue_date=date('Y-m-d');
          $invoice->amount=$amount;
          $invoice->status="Pending";
          $invoice->type="Monthly Invoice";
          $invoice->due_date=date('Y-m-d', strtotime($invoice->issue_date . "+7 days"));
          $invoice->invoice_number=substr(number_format(time() * rand(),0,'',''),0,6);
          $invoice->save(); 
          Helper::CreateTenantMonthlySummary($invoice,$tenant);



          $this->createInvoiceItems($tenant,$invoice);
          $this->CreditTenantAccount($tenant,$invoice);
           
  }
  public function findItemCode($item)
  {
    $model=InvoiceComponent::where(['name'=>$item])->first();
    return ($model)?$model->code:null;

  }

  public function createInvoiceItems($tenant,$invoice)
  {
  try{
      $items=$tenant->charges;
      foreach($items as $item)
      {

        $itemName=$item->charge_name;
        $rentAmount=$item->amount;
        $rentCode=self::findItemCode($itemName);
        $invoiceitem=new InvoiceItem();
        $invoiceitem->invoice_id=$invoice->id;
        $invoiceitem->code= $rentCode;
        $invoiceitem->name=$itemName;
        $invoiceitem->amount=$rentAmount;
        $invoiceitem->save();
              
      }

    }catch(\Exception $e)
    {
      Helper::sendEmailToSupport($e);
      return false;
    }
     

  }



 public function createDeposit($tenant,$amount)
 {

  $deposit=Deposit::where(['tenant_id'=>$tenant->id])->first();
      if(!$deposit){
           $deposit=new Deposit();
        }
        $deposit->amount=$amount;
        $deposit->status="Unpaid";
        $deposit->tenant_id=$tenant->id;
        $deposit->save();
        

 }



    public function createTenant($model,$data){
     try{
            $provider=Property::find($data['property_id']);
            $smokers=(strlen($data['smoker_number'])<1)? 0: $data['smoker_number'];
            $tenant_data=array('user_id'=>$model->id,
              'provider_id'=>$provider->provider_id,
              'space_id'=>$data['space_id'],
              'status'=>'Occupied',
              'has_smokers'=>$data['do_you_have_smokers'],
              'smoker_number'=>$smokers,
              'stay_duration'=>$data['stay_duration'],
              'has_requirement'=>$data['has_requirement'],
              'requirement'=>$data['requirement'],
              'scanned_id'=>0,
              'type'=>$data['employement_type'],
              'expected_end_date'=>date('Y-m-d',strtotime($data['expected_end_date'])),
              'entry_date'=>date('Y-m-d',strtotime($data['entry_date'])),
            );
            $tenant=Tenant::create($tenant_data);
            $charges=$this->createTenantCharges($tenant,$data);
            if($charges)
            { 
             $this->createTenantFirstInvoice($tenant);
           }

           if($tenant->type=="Student"){
            $this->createStudent($tenant,$data);

          }elseif($tenant->type=="Employed"){
            $this->createEmployer($tenant,$data);
          }
          $this->createEmergencyContact($tenant,$data);
          $pet_present=$data['do_you_have_pet'];
          if($pet_present=="Yes"){
            $this->addPossession($tenant,$data,"pet");
          }
          $vehicle_present=$data['do_you_have_vehicle'];
          if($vehicle_present=="Yes"){
            $this->addPossession($tenant,$data,"vehicle");
          }
          $space=$tenant->space;
          if($space)
          {
           $space->status="Occupied";
           $space->save();
         }
         return $tenant;

 }
catch(\Exception $e)
 {
  Helper::sendEmailToSupport($e);
  return false;
}
 }


     public function createStudent($tenant,$data){

       $student=Student::where(['tenant_id'=>$tenant->id])->first();
        if(!$student){
        $student=new Student();
        }
       $student->tenant_id=$tenant->id;
       $student->reg_number=$data['reg_number'];
       $student->institution_name=$data['university_name'];
       $student->year_of_study=$data['year_of_study'];
       $student->course_title=$data['course'];
       $student->course_duration=$data['course_length'];
       $student->save();
       return true;

     }
     public function createEmployer($tenant,$data){
       $employer=Employer::where(['tenant_id'=>$tenant->id])->first();
        if(!$employer){
      $employer=new Employer();
        }

      $employer->tenant_id=$tenant->id;
      $employer->employer_name=$data['employer'];
      $employer->job_title=$data['job_title'];
      $employer->contact_name=$data['reference_name'];
      $employer->contact_phone=$data['reference_phone'];
      $employer->status="Pending";
      $employer->save();
       return $employer;
     }


     public function addPossession($tenant,$data,$product){
       if($product=="pet"){
        $type="Pet";
        $pos_name=$pet_name=$data['pet_name'];
        $pos_number=$pet_number=$data['pet_number'];

          }else{
          $pos_name=$data['body_type'];
          $type="Vehicle";
          $pos_number=$data['vehicle_number'];
          }
      
        
          foreach($pos_name as $key=>$value)
          {
            $mod=new Possession();
            $mod->tenant_id=$tenant->id;
            $mod->type=$type;
            $mod->name=$pos_name[$key];
            $mod->number= $pos_number[$key];
           
            $mod->save();
          }
        return true;
     }


     private function  verifyRole($user){
         $role_id=Role::where(['name'=>'Renter'])->first()->id;
        if($role_id){
           return $role_id;
        }
        else{
            return false;
        }
       
   }

   public function createProfile($user,$data)
   {
     
     $profile_data=array('user_id'=>$user->id,
                        'gender'=>$data['gender'],
                        'telephone'=>Helper::processNumber($data['phone']),
                        'postal_address'=>$data['postal_address'],
                        'status'=>'Incomplete',
                        'id_number'=>$data['id_number'],
                        'timezone'=>'Africa/Nairobi',
                        );
     $message="Dear ".$user->name." You have a new Account created for you on qooetu.com for accessing your rental properties.To access your account use \n 
     Email : ".$user->email." \n Password :".$data['id_number'];
     $telephone=Helper::processNumber($data['phone']);
      Helper::sendSms($telephone,$message);
     $profile=Profile::create($profile_data);
     return $profile;

   }

   public function createEmergencyContact($tenant,$data){
     $contact_data=array('tenant_id'=>$tenant->id,
                          'name'=>$data['kin_name'],
                          'relationship'=>$data['relationship'],
                          'postal_address'=>$data['conatct_postal_address'],
                          'postal_code'=>$data['conatct_postal_address'],
                          'email'=>$data['kin_email'],
                          'phone'=>$data['tel']
                           );
        $model=EmergencyContact::where(['tenant_id'=>$tenant->id])->first();
         if(!$model){
            $model=EmergencyContact::create($contact_data);

         }
         else{
            $model->update($contact_data);
         }

        $this->createSpaceOccupancy($tenant,$data);
         return true;
   }


   public function  createSpaceOccupancy($tenant,$data){

        $occupant_name=$data['person_name'];
        $occupant_identification=$data['identification'];
        $occupant_number=$data['occupant_number'];
        $occupant_age=$data['age'];
        $total=0;
         $current_occupants=TenantsOccupant::where(['tenant_id'=>$tenant->id])->get();
           if(sizeof($current_occupants)>0){
             foreach($current_occupants as $kid){
               $kid->delete();

             }

           }
          foreach($occupant_name as $key=>$value)
          {

            if(isset($occupant_number[$key]) && !empty($occupant_number[$key])){
              
            $mod=new TenantsOccupant();
            $mod->tenant_id=$tenant->id;
            $mod->name=$occupant_name[$key];
            $mod->identification=$occupant_identification[$key];
            $mod->number= $occupant_number[$key];
            $mod->age =$occupant_age[$key];
            $mod->save();

            }
           
            

            
          }

    
        return true;
       }


   public function createTenantPayments($tenant,$data,$total=0,$deposit_paid=0,$invoice=null)
   {
      $system_ref=str_random(7);
      $payment=new TenantPayment();
      $payment->tenant_id=$tenant->id;
      $payment->payment_mode="Cash";
      $payment->reference_number=strtoupper(str_random(13));
      $payment->type="Payment Reversal";
      $payment->space_id=$tenant->space_id;
      $payment->provider_id=$tenant->provider_id;
      $payment->debit=0;
      $payment->credit=$total;
      $payment->fee_charges=0;
       if(isset($invoice)){
        $payment->invoice_id=$invoice->id;
       }
       $payment->transaction_date=date('Y-m-d');
       $payment->system_transaction_number=$system_ref;
       $payment->description='Being New Payment For The Space';
       
       $payment->save();
       return $payment;
   }

   public function fetchTenants()
   {
    if(Entrust::hasRole("Provider"))
       {
        $data['page_title']="Tenant Management";
        //$data['tenants']=Tenant::where(['provider_id'=>Auth::User()->getProvider->id])->get();
        return view('backend::tenants.index',$data);
        }
       else
       {
        return view("forbidden");
       }
   }


   public function fetchdepositpayments(){

    if(Entrust::hasRole("Provider"))
       {
        $data['page_title']="Payment Management";
        $data['payments']=TenantPayment::where(['type'=>'Deposit','provider_id'=>Auth::User()->getProvider->id])->get();
        return view('backend::tenants._index',$data);
        }
       else
       {
        return view("forbidden");
       }

   }
   public function fetchrentPayments(){
    if(Entrust::hasRole("Provider"))
       {
        $data['page_title']="Payment Management";
        $data['payments']=TenantPayment::where(['type'=>'Rent','provider_id'=>Auth::User()->getProvider->id])->get();
        return view('backend::tenants._rindex',$data);
        }
       else
       {
        return view("forbidden");
       }

   }
   public function getInvoiceDetails($id)
   {
    $invoice=Invoice::find($id);
     
      if($invoice)
      {
         
        $user=$invoice->user;
        $data=array('name'=>$user->name,
                     'telephone'=>$user->profile->telephone,
                     'id_number'=>$user->profile->id_number,
                     'email'=>$user->email,
                     'invoice_number'=>$invoice->invoice_number,
                     'date_billed'=>$invoice->issue_date,
                     'invoice_amount'=>$invoice->amount,
                     'space'=>$invoice->space->number,
                     'property'=>$invoice->space->property->title,
                     'amount_paid'=>$invoice->amount_paid,
                     'balance'=>$invoice->balance,

                   );
         return json_encode($data);

      }

   }

   public function makepayment(){
    if(Entrust::hasRole("Provider"))
       {
        $data['page_title']="Payment Management";
        $models=Property::where(['provider_id'=>Auth::User()->getProvider->id])->get();
        $data['properties']=$models;
        $data['invoice_id']=(isset($_GET['invoice_id']))?$_GET['invoice_id']:0;

        return view('backend::tenants.create_payment',$data);
        }
       else
       {
        return view("forbidden");
       }

   }

   public function getTenantDetails($id)
   {
      $model=Tenant::where(['space_id'=>$id])->first();
       if($model){
        $data=array('id'=>$model->id,'name'=>$model->user->name,'email'=>$model->user->email,'id_number'=>$model->user->profile->id_number,'phone'=>$model->user->profile->telephone);
        return json_encode($data);


       }
       else{
        echo json_encode("Tenant Details not Found");
       }
   }

   public function storePayment(Request $request)
   {
    //DB::beginTransaction();
    $this->validate($request,[
  
        'space_id'=>'required|exists:spaces,number',
        'reference_number'=>'required|unique:tenant_payments',
        'payment_mode'=>'required|string',
        'credit'=>'required|integer',
        'transaction_date'=>'nullable|date',
        'description'=>'required'
        ]);
    $data=$request->all();
    
      
     

      try{

    
     $invoice=Invoice::where(['invoice_number'=>$data['invoice']])->first();
     $property=Property::where(['title'=>$data['property_id']])->first();
     $space=Space::where(['property_id'=>$property->id,'number'=>$data['space_id']])->first();
     $tenant=Tenant::where(['space_id'=>$space->id])->first();
      
      $comm_percentage=$property->agent_commission_percentage;
      
    if($tenant):
     
   $payment_data=array('provider_id'=>$tenant->provider_id,
                        'space_id'=>$space->id,
                        'invoice_id'=>$invoice->id,
                        'reference_number'=>$data['reference_number'],
                        'credit'=>0,
                        'debit'=>$data['credit'],
                        
                        'description'=>$data['description'],
                        'payment_mode'=>$data['payment_mode'],
                        'type'=>$invoice->type,
                        'transaction_date'=>date('Y-m-d',strtotime($data['transaction_date'])),
                        'system_transaction_number'=>str_random(8),
                        'year'=>date('Y'),
                        'month'=>date('m'),
                        'fee_charges'=>0,
                        'tenant_id'=>$tenant->id,
                        );

    
    $model=TenantPayment::create($payment_data);
     
      if($model){
         if(isset($data['receipt']))
         {
          Helper::uploadReceipt($model,$data);
         }
         
          
         $amount=$invoice->amount_paid+$data['credit'];
          
        $invoice->amount_paid=doubleval($amount);
        
        if(strlen($invoice->balance)<1)
          {
            $invoice->balance=$invoice->amount;
            $invoice->save();
          }

        $invoice->balance=$invoice->amount-$invoice->amount_paid;
        $invoice->status=($invoice->balance>0)?"Pending":"Paid";
        $invoice->save();

       
          if(isset($data['itemIds']))
          {
            $ids=$data['itemIds'];
            $amounts=$data['itemAmount'];

              foreach($ids as $key=>$value)
              {
                 
                 $id=$ids[$key];
                 $amount=$amounts[$key];
                
                  //dd($amount);
                $invoiceitem=InvoiceItem::find($id);
                 if($invoiceitem)
                 {

                   

                     

                   
            /*$component=InvoiceComponent::where(['name'=>$invoiceitem->name])->first();
              dd($component);*/
                   $invoiceitem->amount_paid=$amount;
                  $invoiceitem->balance=$invoiceitem->amount-$invoiceitem->amount_paid;
                  $invoiceitem->save();

                 $test= Helper::updateTenantMonthReport($invoiceitem,$tenant,$model);

                               
                    

                 }
                 

              }

          }
         

         
         DB::commit();
         //$this->sendReceipt($model,$invoice);
         
         Session::flash("success_msg","Payment Received successfully and receipt emailed to the tenant");
         return redirect('/backend/invoices/index?status=Pending');
          

       
       
         

      }
    Session::flash('success_msg','Payment Saved Successfully');
    return redirect()->back();

     else:

    return redirec()->back()->withErrors("Tenant Specified Not Found ");

    endif;


      }catch(\Exception $e)
       {
         dd($e);
       }
     
     }

   public function sendReceipt($model,$invoice)
   {
    $receipt=Receipt::generate($model,$invoice);
   }
   public function createMyPayment($comm,$comm_amount,$opayment)
   {
                   $payment=new Payment();
                   $payment->amount=$comm_amount;
                   $payment->month=$opayment->month;
                   $payment->year=$opayment->year;
                   $payment->space_id=$opayment->space_id;
                   $payment->property_id=$opayment->property_id;
                   $payment->charge_id=$comm->id;
                   $payment->tenant_id=$opayment->tenant_id;
                   $payment->save();
                    

   }

  


   public function emergency_contact(){
     if(Entrust::hasRole("Provider")){
      $data['page_title']="Emergency Contacts For Tenants";
       return view('backend::tenants.emergency_contacts',$data);
     }else{
      return view("forbidden");
     }
   }


   public function  registered_items(){
    if(Entrust::hasRole("Provider")){
      $id=Auth::User()->getProvider->id;
      $data['page_title']="Assets Management";
        return view('backend::tenants.registered_items',$data);
      
      }else{
      return view("forbidden");
    }

   }

   public function getoccupants(){
    if(Entrust::hasRole("Provider")){
      $id=Auth::User()->getProvider->id;
      $data['page_title']="Occupant Management";
        return view('backend::tenants.occupants_list',$data);
      
      }else{
      return view("forbidden");
    }

   }


   public function view($id){
     if(Entrust::hasRole("Provider")){
      $provider_id=Auth::User()->getProvider->id;
       $model=Tenant::where(['provider_id'=>$provider_id,'id'=>$id])->first();

        if(!$model){
          return view("not_found");
        }
        $data['model']=$model;
        $data['contact']=$model->contact;
        $data['occupants']=$model->occupants;
        $data['items']=$model->items;
        $data['payments']=$model->payments();
        $data['page_title']="Tenants Details";
        return view('backend::tenants.detail_view',$data);

     }else{
      return  view("forbidden");
     }
   }
       

    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit()
    {
        return view('backend::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(Request $request)
    {
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy()
    {
    }



    public function add_new_occupant($id,Request $request){
      $method = $request->method();

      $model=new TenantsOccupant();
       

     
       if($request->isMethod('post')) {
        $data=$request->all();
        $tenant=array('tenant_id'=>$id);
        $data=array_merge($data,$tenant);
        unset($data['_token']);

         $model=TenantsOccupant::firstOrCreate($data);
          if($model){
            Session::flash("success_msg","Occupant Added Successfully");

          }else{
           Session::flash("danger_msg",$model->errors());
          }
          $url_to=url('/backend/tenant/view/'.$id);
          return redirect($url_to);


       }else{
        $url=url("backend/tenant/add_occupants/".$id);
         $data['url']=$url;
         $data['model']=$model;
         return view('backend::tenants.add_occupant',$data);

       }


    }

    public function edit_occupant($id,Request $request){
      $model=TenantsOccupant::find($id);
       if($request->isMethod("post")){
         $data=$request->all();
         $model->update($data);

          if($model){
            Session::flash("success_msg","Occupant Updated Successfully");

          }else{
           Session::flash("danger_msg",$model->errors());
          }
          $url_to=url('/backend/tenant/view/'.$model->tenant_id);

          return redirect()->back();
        }else{
        $url=url("backend/tenants/edit_occupant/".$id);
        $data['url']=$url;
        $data['model']=$model;
        $data['label']="Update";
        //$data['occupant']=$model->occupants;

         return view('backend::tenants.add_occupant',$data);

       }


    }


    public function delete_occupant($id){
      if(Entrust::hasRole("Provider")){
        $provider_id=Auth::User()->getProvider->id;
        $model=TenantsOccupant::find($id);
            if($model){
              
              $model->delete();

              Session::flash("success_msg",'Occupant Deleted successfully');

            }else{
              Session::flash("danger_msg",'Resource you are trying to delete was not found on this server');
            }

      }else{
        Session::flash("danger_msg",'You do not have permissions to perform this task');
      }
    }


    public function add_item($id,Request $request){
       $model=new Possession();
       if($request->isMethod("Post")){
        $data=$request->all();
        $tenant=array('tenant_id'=>$id);
        $data=array_merge($data,$tenant);
        unset($data['_token']);

         $model=Possession::firstOrCreate($data);
          if($model){
            Session::flash("success_msg","Item Added Successfully");

          }else{
           Session::flash("danger_msg",$model->errors());
          }
          $url_to=url('/backend/tenant/view/'.$id);
          return redirect($url_to);

       }else{
        $data['url']=url('/backend/tenant/add_item/'.$id);
        $data['model']=$model;
        return view('backend::tenants.add_item',$data);
       }
    }

    public function edit_item($id,Request $request){

      $model=Possession::find($id);
     
       if($request->isMethod("post")){
         $data=$request->all();
         $model->update($data);

          if($model){
            Session::flash("success_msg","Item Updated Successfully");

          }else{
           Session::flash("danger_msg",$model->errors());
          }
          

          return redirect()->back();



       }else{
        $url=url("backend/tenants/edit_item/".$id);
        $data['url']=$url;
        $data['model']=$model;
        $data['label']="Update";
         return view('backend::tenants.add_item',$data);

       }


    }

     public function delete_item($id){
      if(Entrust::hasRole("Provider")){
        $provider_id=Auth::User()->getProvider->id;
        $model=Possession::find($id);
            if($model){
              
              $model->delete();

              Session::flash("success_msg",'Item Deleted successfully');

            }else{
              Session::flash("danger_msg",'Resource you are trying to delete was not found on this server');
            }

      }else{
        Session::flash("danger_msg",'You do not have permissions to perform this task');
      }
    }



    public function edit_contact(Request $request,$id){
      $model=EmergencyContact::find($id);

      if($request->isMethod("post")){
         $data=$request->all();
          if($model->update($data)){
            Session::flash("success_msg","Details updated successfully");
          }

          return redirect()->back();

      }else{
        $data['model']=$model;
        $data['url']=url('/backend/tenants/contact/'.$id);
        $data['label']='Update';

      return view('backend::tenants.edit_contact',$data);

      }

    }

    public function updateTenant($id=null)
    {
        if(Entrust::hasRole("Provider")){
             $provider_id=Auth::User()->getProvider->id;
           $model=Tenant::where(['provider_id'=>$provider_id,'id'=>$id])->first();
            if($model){
              $data['page_title']="Update Tenant's Details";
              $data['model']=$model;
              $data['deposit']=Deposit::where(['tenant_id'=>$model->id])->first()->amount;
              $models=Property::where(['provider_id'=>Auth::User()->getProvider->id])->get();
              $data['properties']=$models;
              $data['space']=Space::find($model->space_id);

               
              
              return view('backend::tenants.edit_tenant',$data);



            }else{
              return view("not_found");
            }




        }else{
          return view("forbidden");
        }
    }

    public function getstudents(){
       if(Entrust::hasRole("Provider")){
        $data['page_title']="Students Tenants";
        $data['students']=Student::join('tenants','students.tenant_id','=','tenants.id')->where(['type'=>'Student'])->orderBy('reg_number')->get();
         return view('backend::tenants.student_tenant',$data);
         }else{
        return view("forbidden");
       }
    }

    public function getnonstudent(){
      if(Entrust::hasRole("Provider")){
        $data['page_title']="Tenants Details";
        $data['students']=Employer::join('tenants','employed_tenants.tenant_id','=','tenants.id')->where('type','!=','Student')->get();
         return view('backend::tenants.student_tenant',$data);
         }else{
        return view("forbidden");
       }

    }

    public function updateTdetails(Request $request,$id){

       if(Entrust::hasRole("Provider")){
          $data=$request->all();
                
    DB::beginTransaction();
      $user_data=array('name'=>$data['name'],'email'=>$data['email'],'password'=>$data['id_number'],'verification_code'=>str_random(8),'confirmed_at'=>date('Y-m-d H:i:s'),'provider'=>"Manual");
        $model=User::where(['email'=>$data['email']])->first();
         if($model){
           $user=$model->update($user_data);
           $profile=$this->editProfile($model,$data);
          }

     $this->editTenantD($model,$data);
    return redirect()->back();

       }else{
        return view("forbidden");
       }

    }
    public function editProfile($user,$data)
   {

     
     $profile_data=array('user_id'=>$user->id,
                        'gender'=>$data['gender'],
                        'telephone'=>$data['phone'],
                        'postal_address'=>$data['postal_address'],
                        'status'=>'Incomplete',
                        'id_number'=>$data['id_number'],
                        'timezone'=>'Africa/Nairobi',
                        );
       $profile=Profile::where(['user_id'=>$user->id])->first();
       if($profile){
        $profile->update($profile_data);
       }
       
        return $profile;

   }
    public function editTenantD($model,$data){

      $provider=Property::find($data['property_id']);
       $tenant_data=array('user_id'=>$model->id,
                          'provider_id'=>$provider->provider_id,
                          'space_id'=>$data['space_id'],
                          'status'=>'Occupied',
                          'stay_duration'=>$data['stay_duration'],
                          'has_requirement'=>$data['has_requirement'],
                          'requirement'=>$data['requirement'],
                          'scanned_id'=>0,
                          'type'=>$data['employement_type'],
                          'expected_end_date'=>date('Y-m-d',strtotime($data['expected_end_date'])),
                          'entry_date'=>date('Y-m-d',strtotime($data['entry_date'])),
                          );


       $tenant=Tenant::find($data['tenant_id']);
       $tenant->update($tenant_data);
       

   
        if($tenant->type=="Student"){
          $this->createStudent($tenant,$data);

        }elseif($tenant->type=="Employed"){
          $this->createEmployer($tenant,$data);
        }
      $charge_name=$data['charge'];
      $amount=$data['amount'];
      $date_effective=$data['effective_from'];
         $tenant_charges=TenantCharges::where(['tenant_id'=>$tenant->id])->get();
         $intial_total=TenantCharges::where(['tenant_id'=>$tenant->id])->sum('amount');

         //being refund of the intial payment
          $payment_data=array('tenant_id'=>$tenant->id,
                         'payment_mode'=>'Cash',
                         'reference_number'=>strtoupper(str_random(13)),
                         'type'=>'Intail Payments',
                         
                         'space_id'=>$tenant->space_id,
                         'provider_id'=>$tenant->provider_id,
                         'debit'=>$intial_total,
                         'credit'=>0,
                         'fee_charges'=>0,
                         'transaction_date'=>date('Y-m-d'),
                         'system_transaction_number'=>strtoupper(str_random(10)),
                         'description'=>'Being  Intail Payment Reversal For The Space that was charged on',
                       );
        $payment=TenantPayment::create($payment_data);
          foreach($tenant_charges as $tena){
               $tena->delete();
            }

       
          $total=0;
          $deposit=0;
           
        
          foreach($charge_name as $key=>$value)
          {$mod=new TenantCharges();
            $mod->tenant_id=$tenant->id;
            $mod->charge_name=$charge_name[$key];
            $mod->amount= $amount[$key];
            $mod->effective_from=$date_effective[$key];
            $mod->status="Active";
            $total=$total+$amount[$key];
            $mod->save();
          }
          $deposit=TenantCharges::where(['tenant_id'=>$tenant->id,'charge_name'=>'Deposit'])->first()->amount;
        $payments=$this->createTenantPayments($tenant,$data,$total,$deposit,null);
       $x=$this->createEmergencyContact($tenant,$data);
       $space=Space::find($data['space_id']);
       $space->status="Occupied";
       $space->save();
       $y=$this->editPossession($tenant,$data,"pet");
       
       DB::commit();
       Session::flash('success_msg','Payment Saved Successfully');
    return $this->redirectToHo0me();

       

    }

    public function redirectToHo0me(){
      return redirect('/');
    }

    public function GetInvoiceComponents($number=null)
    {  
      $number=Input::get('Number');
      $model=Invoice::where(['invoice_number'=>$number])->first();
        $i=1;
         foreach($model->items as $item)
         {
          echo '<tr>
          <td>'.$i.'<input type="hidden" name="itemIds[]" value="'.$item->id.'"></td>
        
          <td>'.$item->name.'</td>
          <td>'.$item->amount.'</td>
           <td>'.$item->amount_paid.'</td>
            <td>'.$item->balance.'</td>

             <td><input type="text" class="number"  name="itemAmount[]" required></td>
          </tr>';

          $i++;
         }

    }

    public function editPossession($tenant,$data,$product){
       
        if(isset($data['item_name']))
        {
           $pos_name=$data['item_name'];
          $pos_number=$data['item_number'];
          $pos_type=$data['item_type'];
           $models=Possession::where(['tenant_id'=>$tenant->id])->get();

            if(sizeof($models)>0){
               foreach($models as $mod){
               $mod->delete();
              }
           }
           
             
         foreach($pos_name as $key=>$value)
          {
            $mod=new Possession();
            $mod->tenant_id=$tenant->id;
            $mod->type=$pos_type[$key];
            $mod->name=$pos_name[$key];
            $mod->number= $pos_number[$key];
            $mod->save();
          }

        }
         

        return true;
     }


     public function lease_expiry(){
      if(Entrust::hasRole("Provider"))
       {
        $data['page_title']="Tenant Management";
        $status=(isset($_GET['status']))? $_GET['status']:"All";
        $data['status']=$status;
        return view('backend::tenants._e_index',$data);
        }
       else
       {
        return view("forbidden");
       }

     }

     public function fetch_leases($status){

      if($status=="All"){
        $p_id=Auth::User()->getProvider->id;
        $bookings=Tenant::join('spaces','spaces.id','=','tenants.space_id')
          ->join('users','users.id','=','tenants.user_id')
          ->join('properties','properties.id','=','spaces.property_id')
          ->select(['tenants.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id'])
          ->where(['properties.provider_id'=>$p_id,'current_status'=>'Active'])
          ->get();

      }else{
          if($status=="monthly"){
             $p_id=Auth::User()->getProvider->id;
             $year=date('Y');
             $month=date('m');
        $bookings=Tenant::join('spaces','spaces.id','=','tenants.space_id')
          ->join('users','users.id','=','tenants.user_id')
          ->join('properties','properties.id','=','spaces.property_id')
          ->select(['tenants.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id'])
          ->where(['properties.provider_id'=>$p_id])
          ->whereYear('expected_end_date','=',$year)
          ->whereMonth('expected_end_date','=',$month)
          ->get();

          }elseif($status=="year"){
            $p_id=Auth::User()->getProvider->id;
             $year=date('Y');
             $month=date('m');
            $bookings=Tenant::join('spaces','spaces.id','=','tenants.space_id')
          ->join('users','users.id','=','tenants.user_id')
          ->join('properties','properties.id','=','spaces.property_id')
          ->select(['tenants.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id'])
          ->where(['properties.provider_id'=>$p_id])
          ->whereYear('expected_end_date','=',$year)
          ->get();
          }else{
            $p_id=Auth::User()->getProvider->id;
             $year=date('Y');
             $month=date('m');
        $bookings=Tenant::join('spaces','spaces.id','=','tenants.space_id')
          ->join('users','users.id','=','tenants.user_id')
          ->join('properties','properties.id','=','spaces.property_id')
          ->select(['tenants.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id'])
          ->where(['properties.provider_id'=>$p_id,'current_status'=>$status])
          ->get();
          }
       
      }


       
  return Datatables::of($bookings)
              ->editColumn('name',function($model){
                $url=url('/backend/tenant/view/'.$model->tenant_id);
                return '<a href="'.$url.'" >'.ucwords($model->name).'</a>';



              })
               ->editColumn('current_status',function($model){
                $today=date('Y-m-d');
                 if($model->current_status=="InActive"){
                  return '<label class="label label-danger"> Expired</lable>';
                 }elseif ($today>=$model->expected_end_date) {
                   return '<label class="label label-danger"> Expired</lable>';
                 }

                 else{
                  $ed=\Carbon::parse($model->expected_end_date);
                  $months=$ed->diffInMonths();
                  $days=$ed->diffInDays();
                   if($months<2){
                    return '<label class="label label-warning" title="'.$days.' Days Remaining">'.$model->current_status.' </lable>';
                   }else{
                    return '<label class="label label-success" title="'.$months.' Months Remaining">'.$model->current_status.'</lable>';
                   }



                  
                 }



              })
     
               ->addColumn('action', function ($model) {
                     $url=url('/backend/v-notice/extend/'.$model->id);
                     $url_to=url('/backend/notices/create/'.$model->tenant_id);
                      return '<a data-url="'.$url_to.'" style="cursor:pointer;"  title="Create New Tenant Vaccation Notice" 
                                data-title="Create New Tenants Vaccation Notice"class="icon-clapboard reject-modal"></a>

                              <a  style="margin-left:15%" title="Extend The Lease Period" data-url="'.$url.'" class="glyphicon glyphicon-pencil reject-modal"
                               data-title="Extend The Lease Period"
                              ></a>
                                ';

                    
                    })->make(true);

     }








     public function getChargeBreakdown($space_id){
       $tenant=Tenant::where(['space_id'=>$space_id])->first();
        if(sizeof($tenant->charges)>0){
       $models=$tenant->charges;
       $deposit= TenantCharges::where(['tenant_id'=>$tenant->id,'charge_name'=>'Deposit'])->sum('amount');
       $data['models']=$models;
       $data['deposit']=$deposit;
       $data['monthly']=TenantCharges::where(['tenant_id'=>$tenant->id])
                       ->where('charge_name','!=','Deposit')
                       ->sum('amount');
         return view('backend::tenants._charge',$data);
        }else{
           return "<h4 style='color:red'>No Charges Break Down Has Been Provided For This Client<h3>";
        }
     }

     public function getBreakdown($id){
       $tenant=Tenant::where(['id'=>$id])->first();
        if(sizeof($tenant->charges)>0){
       $models=$tenant->charges;
       $deposit= TenantCharges::where(['tenant_id'=>$tenant->id,'charge_name'=>'Deposit'])->sum('amount');
       $data['models']=$models;
       $data['deposit']=$deposit;
       $data['monthly']=TenantCharges::where(['tenant_id'=>$tenant->id])
                       ->where('charge_name','!=','Deposit')
                       ->sum('amount');
         return view('backend::tenants._charge',$data);
        }else{
           return "<h4 style='color:red'>No Charges Break Down Has Been Provided For This Client<h3>";
        }

     }



     public function getTenancy($space_id){
      $tenancy=Tenant::where(['space_id'=>$space_id])->get();
        if(sizeof($tenancy)<1){
          return "<h4 style='color:red'> TO Tenants Have Occupied The Space/Unit </h4>";

        }else{
          $data['tenancy']=$tenancy;
          return view('backend::tenants._space_tanants',$data);
        }

     }

     public function extendTenancy($id,Request $request){
        $model=Tenant::find($id);
         if(!$model){
          return "Resource Was Not Found on Our Server";
         }

         if($request->isMethod("post")){
           DB::beginTransaction();
           $data=$request->all();
            $model->expected_end_date=date('Y-m-d',strtotime($data['expected_end_date']));
            $model->current_status="Active";
            $model->save();
            $model->space->status="Occupied";
            $model->space->save();
            DB::commit();

             Session::flash('success_msg',"Tenancy Period Extended Successfully");
             return redirect()->back();

         }
         $data['model']=$model;

         $data['url']=url('/backend/v-notice/extend/'.$model->id);
         return view('backend::notice.extend_tenancy',$data);




     }


     public function getInvoices(){
       if(Entrust::hasRole("Provider"))
       {
        $data['page_title']="Invioce Management";
         $status=(isset($_GET['status']))? $_GET['status']:"all";
         $data['status']=ucwords($status);

         return view('backend::tenants.invoices',$data);
        }
       else
       {
        return view("forbidden");
       }

     }
     public function downloadInvoices($id)
     {
       $model=Invoice::find($id);
        if($model)
        {
          
          InvoicePDf::generate($model);
        }

     }




     public function getbalances(){
      if(Entrust::hasRole("Provider"))
       {
        $data['page_title']="Balance Management";
         $status=(isset($_GET['status']))? $_GET['status']:"all";
         $data['status']=ucwords($status);
         return view('backend::payments.balances',$data);
        }
       else
       {
        return view("forbidden");
       }


     }


     public function getInvoiceStats(){
       if(Entrust::hasRole("Provider"))
       {
        $data['page_title']="Invioce Statistics";
        $model=new Invoice();
        $data['model']=$model;
        $data['provider_id']=Auth::User()->getProvider->id;
         
        return view('backend::tenants.invoice_stats',$data);
        }
       else
       {
        return view("forbidden");
       }

     }

     public function invoiceView($id){
       if(Entrust::hasRole("Provider") || Entrust::hasRole("Renter"))
       {
        $data['page_title']="Invioce Statistics";
         if(Entrust::hasRole("Provider"))
          {
            $provider_id=Auth::User()->getProvider->id;
              $data['provider']=Auth::User()->getProvider;

        $model=Invoice::where(['id'=>$id,'provider_id'=>$provider_id])->first();

          }else{



        $model=Invoice::where(['id'=>$id,'issued_to'=>auth::user()->id])->first();

          }
        
        $data['model']=$model;
       
        return view('backend::tenants._invoice',$data);
        }
       else
       {
        return view("forbidden");
       }


     }


     public function viewRepairCosting($id){

       if(Entrust::hasRole("Provider") || Entrust::hasRole("Admin") || Entrust::hasRole("Renter"))
       {
        $data['id']=$id;
        $model=Repair::find($id);
         if(!$model){
          return "Repair Details Not Found";
         }
         $supplier=new Supplier();
         $invoice=Invoice::where(['invoice_number'=>$model->invoice_number])->first();
         $data['model']=$model;
         $data['invoice']=$invoice;
         $data['supplier']=$supplier;
         return view('backend::repairs._costing',$data);
        }
       else
       {
        return view("forbidden");
       }


     }


     public function getTechnician($id){
      if(Entrust::hasRole("Provider") || Entrust::hasRole("Renter"))
       {
        $data['id']=$id;
        $model=Repair::find($id);
         if(!$model){
          return "Repair Details Not Found";
         }
         $invoice=Invoice::where(['invoice_number'=>$model->invoice_number])->first();
         $data['model']=$model;
         $data['invoice']=$invoice;
         return view('backend::repairs._technician',$data);
        }
       else
       {
        return view("forbidden");
       }

     }

     public function verifyInvoice(){
       $q=Input::get('term');

        if(strlen($q)>3){


        $models=Invoice::where('invoice_number','like','%'.$q.'%')->get();
         

        if(sizeof($models)>0){
           $data=array();
       foreach($models as $model){

         $invoice=Invoice::find($model->id);
          $user_name=$invoice->user->name;
          $phone=$invoice->user->profile->telephone;
          $space=$invoice->space->number;
          $property=$invoice->space->property->title;
          $id_number=$invoice->user->profile->id_number;
           $date_billed=$invoice->issue_date;
           $email=$invoice->user->email;
           $description=$invoice->description;
           $expected_amoutnt=$invoice->amount;
           $invoice_id=$invoice->invoice_number;
           $data[]=array($invoice_id,$date_billed,$property,$space,$user_name,$id_number,$email,$phone,$expected_amoutnt,$description);
    
       }
      
   
   $data=json_encode($data);
   return $data;


        }else{

          $data=json_decode("Invoice Not Found In Our Records");
           return $data;

        }
      

    }


     }


     public function fetchTenantsList(){
        $p_id=Auth::User()->getProvider->id;
        $models=Tenant::join('spaces','spaces.id','=','tenants.space_id')
          ->join('users','users.id','=','tenants.user_id')
          ->join('properties','properties.id','=','spaces.property_id')
          ->join('profiles','profiles.user_id','=','users.id')
          ->select(['tenants.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id','tenants.space_id','users.email','telephone','tenants.updated_at','tenants.created_at','users.id as user_id'])
          ->where(['properties.provider_id'=>$p_id,'current_status'=>'Active']);
         
           return Datatables::of($models)
           ->editColumn('name',function($model){
            return str_limit($model->name,25);

           })
           ->editColumn('updated_at',function($model){
            $tenant_id=$model->id;
            $space_id=$model->space_id;

             $model=TenantPayment::where(['tenant_id'=>$tenant_id,'space_id'=>$space_id])->latest('id')->first();

                if($model){
                  $balance=$model->balance;
                }else{
                  $balance=0;
                }

           return $balance;
             })
            ->editColumn('created_at',function($model){
            $tenant_id=$model->id;
            $space_id=$model->space_id;

             $model=TenantPayment::where(['tenant_id'=>$tenant_id,'space_id'=>$space_id])->latest('id')->first();
              $totals=TenantCharges::where(['tenant_id'=>$tenant_id,'charge_name'=>'Rent'])->sum('amount');

           return $totals;
             })
           ->addColumn('action',function($model){
            $edit_url=url('/backend/tenant/update/'.$model->id);
            $view_url=url('/backend/tenant/view/'.$model->id);
            $unit_url=url('/backend/space/view/'.$model->space_id);
            $create_vr_url=url('/backend/notices/create/'.$model->id);
            $invoices_url=url('/backend/tenant/invoice/'.$model->user_id);
            $transaction_url=url('/backend/payment/history?tenant_id='.$model->id);
            $charges_url=url('/backend/payment/tenants/charges?tenant_id='.$model->id);
            $addcharge_url=url('/backend/new_charge/create/'.$model->id);
            $addition_url=url('/backend/addition_charge/list/'.$model->id);
            $login_url=url('/backend/tenant/editLogin/'.$model->id);


            return ' <ul class="icons-list">
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                          <i class="icon-menu9"></i>
                        </a>

                        <ul class="dropdown-menu dropdown-menu-right">
                        
                          <li><a href="'.$edit_url.'"><i class="icon-pencil3"></i> Edit Details</a></li>

                          <li><a class="reject-modal"  data-title="Edit User Logins" data-url="'.$login_url.'"><i class="icon-pencil3"></i> Edit Logins</a></li>
                          <li><a href="'.$view_url.'"><i class="icon-file-eye"></i> Detail View</a></li>
                          <li><a href="'.$unit_url.'"><i class=" icon-library2"></i> Unit Details</a></li>
                          <li><a   style="cursor:pointer;"  title="Create New Tenant Vaccation Notice" class="reject-modal"
                                data-title="Create New Tenants Vaccation Notice"   data-url="'.$create_vr_url.'"
                                 ><i class="icon-clapboard"></i> Create V-Request</a></li>
                          <li><a href="'.$invoices_url.'"><i class="icon-folder-search"></i>View Client Invoices</a></li>
                          <li><a href="'.$transaction_url.'"><i class="icon-stack2"></i>Payment History</a></li>
                           <li><a  class="reject-modal" data-title="Add New Charge To Tenants Account" data-url="'.$addcharge_url.'"><i class="icon-stack2"></i>Add Charge</a></li>
                          <li><a href="'.$addition_url.'"><i class="icon-list"></i>Additional Charges Incured</a></li>

                          
                          <li><a href="'.$charges_url.'"><i class="icon-quill4"></i> Charges Break Down</a></li>

                        
                           
                        </ul>
                      </li>
                    </ul>';

              })

           ->make(true);
     }


     public function fetchTenantInvoice($id){
      $data['page_title']="Tenant Invoices";
      $data['user_id']=$id;
      $data['user']=User::find($id);
      return view('backend::tenants._invoicelist',$data);


     }


     public function addCharge($id,Request $request)
     {
       if(Entrust::hasRole("Provider"))
       {
        $model=Tenant::find($id);
         $data['url']=url()->current();
         $data['model']=$model;
          if($request->isMethod("post"))
          {
            $data=$request->all();
           try{
             DB::beginTransaction();
             $charge=new AdditionCharge();
             $charge->charge_name=strtoupper($data['charge_name']);
             $charge->charge_amount=doubleval($data['charge_amount']);
             $charge->charge_code=strtoupper(str_random(5));
             $charge->charge_status="Active";
             $charge->charge_description=$data['charge_description'];
             $charge->charge_date=date("Y-m-d");
             $charge->year=date("Y");
             $charge->month=date("M");
             $charge->notification=($data['send_notification']=="Yes")?1:0;
             $charge->provider_id=$model->provider_id;
             $charge->tenant_id=$model->id;
             $charge->property_id=$model->space->property_id;
             $charge->space_id=$model->space->id;
              $charge->save();
              if($charge)
              {
                $invoice=new Invoice();
                $invoice->provider_id=Auth::User()->getProvider->id;
                $invoice->issued_to=$model->user_id;
                $invoice->space_id=$model->space->id;
                $invoice->issue_date=date('Y-m-d');
                $invoice->amount=doubleval($data['charge_amount']);
                $invoice->status="Pending";
                $invoice->due_date=date('Y-m-d', strtotime($invoice->issue_date . "+30 days"));
                $invoice->invoice_number=substr(number_format(time() * rand(),0,'',''),0,6);
                $invoice->save(); 
                 





                $system_ref=str_random(7);
                $payment=new TenantPayment();
                $payment->tenant_id=$model->id;
                $payment->payment_mode="Cash";
                $payment->reference_number=$charge->charge_code;
                $payment->type=$charge->charge_name;
                $payment->space_id=$charge->space_id;
                $payment->provider_id=$charge->provider_id;
                $payment->debit=0;
                $payment->credit=$charge->charge_amount;
                $payment->fee_charges=0;
                $payment->invoice_id=$invoice->id;
                $payment->transaction_date=date('Y-m-d');
                $payment->system_transaction_number=$charge->charge_code;
                $payment->description='Being New Payment For '.$charge->charge_name;
               $payment->save();

                if($charge->notification==1)
                {
                  $text="Dear ".$model->user->name." addition charge ".$charge->charge_name." for KES ".$charge->charge_amount." has been added to your account.for more info,access your rental account at ".config('app.name');
                  $phone=str_replace('-','',$model->user->profile->telephone);
                   Helper::sendSms($phone,$text);
                   Helper::sendEmail($model->user->email,$text,"New Addition Charge");
                }
       
                DB::commit();
                Session::flash("success_msg","Charge Added to provider Account successfully");
                return redirect()->back();
              }


              dd($charge);



              }catch(\Exception $e)
               {
                 dd($e);
               }
          }

         return view('backend::tenants._addcharge',$data);
        }
       else
       {
        return view("forbidden");
       }

     }
     public function editLoginDetails($id,Request $request)
     {
        $tenant=Tenant::find($id);
         if($tenant)
         {
          $user=$tenant->user;
           
            $user=User::find($tenant->user_id);
            $data['user']=$user;
           $data['model']=$tenant;
           $data['url']=url()->current();

            if($request->isMethod("post"))
            {
              $data=$request->all();
              
              $new_user=User::where(['email'=>$data['email']])->first();
              if(!$new_user)
              {
                $new_user=$user;
              }
               
              $new_user->email=$data['email'];
              $new_user->name=$data['name'];
              $new_user->password=$data['password'];
              $new_user->username=$data['username'];
              $new_user->save();
              $message="Dear ".$user->name.",your user login details for ".config('app.name')." are <p>Email :".$user->email."<br>Password :".$data['password'];
               Helper::sendEmail($user->email,$message,"User Login Details");

              Session::flash("success_msg","User Details Updated Successfully");
              return redirect()->back();

               
            }




           return view('backend::tenants.user',$data);



         }

     }

     public function getAdditionCharges($id)
     {


       if(Entrust::hasRole("Provider"))
       {
         $data['page_title']="Additional Charges";
         $data['tenant_id']=$id;
         return view('backend::tenants._chargelist',$data);
        }
       else
       {
        return view("forbidden");
       }


     }


     public function paymentHistory(){


       if(Entrust::hasRole("Provider"))
       {
         $data['page_title']="Tenant Transactions";
         $data['tenant_id']=(isset($_GET['tenant_id']))? $_GET['tenant_id'] :'All';
         return view('backend::tenants._paymentlist',$data);
        }
       else
       {
        return view("forbidden");
       }

     }

     public function getSpacePaymentHistory($space_id){

     
      $p_id=Auth::User()->getProvider->id;
        $models=TenantPayment::join('tenants','tenants.id','=','tenant_payments.tenant_id')
          ->join('users','users.id','=','tenants.user_id')
           ->join('spaces','tenants.space_id','=','spaces.id')
            ->join('properties','properties.id','=','spaces.property_id')
              ->join('profiles','profiles.user_id','=','users.id')
          ->where(['tenant_payments.space_id'=>$space_id])
          ->select(['tenants.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id','tenants.space_id','users.email','telephone','tenants.updated_at','tenants.created_at','users.id as user_id','balance','debit','credit','reference_number','transaction_date','invoice_id']);
        return Datatables::of($models)
           ->editColumn('name',function($model){
            list($a,$b)=explode(' ', $model->name);
             return ucwords($a)." " .ucfirst($b);

           })
           ->editColumn('invoice_id',function($model){
            $invoices_url=url('/backend/invoice/view/'.$model->invoice_id);

            $model=Invoice::find($model->invoice_id);
              if($model){
                return '<a href="'.$invoices_url.'" >'.$model->invoice_number.'</a>';


                //$model->invoice_number;
              }else{
                return "Not Set";
              }



           })->make(true);



     }



     public function getPaymentHistory($tenant_id){
         

          if($tenant_id=="All"){
            $p_id=Auth::User()->getProvider->id;
        $models=TenantPayment::join('tenants','tenants.id','=','tenant_payments.tenant_id')
          ->join('users','users.id','=','tenants.user_id')
          ->join('spaces','tenants.space_id','=','spaces.id')
          ->join('properties','properties.id','=','spaces.property_id')
          ->join('profiles','profiles.user_id','=','users.id')
          ->select(['tenants.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id','tenants.space_id','users.email','telephone','tenants.updated_at','tenants.created_at','users.id as user_id','balance','debit','credit','reference_number','transaction_date','invoice_id'])
          ->where(['properties.provider_id'=>$p_id]);

          }else{
            $p_id=Auth::User()->getProvider->id;
        $models=TenantPayment::join('tenants','tenants.id','=','tenant_payments.tenant_id')
          ->join('users','users.id','=','tenants.user_id')
          ->join('spaces','tenants.space_id','=','spaces.id')
          ->join('properties','properties.id','=','spaces.property_id')
          ->join('profiles','profiles.user_id','=','users.id')
          ->select(['tenants.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id','tenants.space_id','users.email','telephone','tenants.updated_at','tenants.created_at','users.id as user_id','balance','debit','credit','reference_number','transaction_date','invoice_id'])
          ->where(['properties.provider_id'=>$p_id,'tenant_id'=>$tenant_id]);
          }
        
         
           return Datatables::of($models)
           ->editColumn('name',function($model){
            list($a,$b)=explode(' ', $model->name);
             return ucwords($a)." " .ucfirst($b);

           })
           ->editColumn('invoice_id',function($model){
            $invoices_url=url('/backend/invoice/view/'.$model->invoice_id);

            $model=Invoice::find($model->invoice_id);
              if($model){
                return '<a href="'.$invoices_url.'" >'.$model->invoice_number.'</a>';


                //$model->invoice_number;
              }else{
                return "Not Set";
              }



           })->make(true);

     }

     public function getTenantsCharges(){
       if(Entrust::hasRole("Admin") || Entrust::hasRole("Provider") || Entrust::hasRole("Renter")){
        $data['page_title']="Tenant Charge Break Down";
        $data['tenant_id']=(isset($_GET['tenant_id']))? $_GET['tenant_id']:"All";
      return view('backend::tenants.charge_break',$data);

       }else{
        return view('forbidden');
       }
      
     }

     public function getTenantCharges($tenant_id){

       if($tenant_id=="All"){
            $p_id=Auth::User()->getProvider->id;
        $models=TenantCharges::join('tenants','tenants.id','=','tenant_charges.tenant_id')
          ->join('users','users.id','=','tenants.user_id')
          ->join('spaces','tenants.space_id','=','spaces.id')
          ->join('properties','properties.id','=','spaces.property_id')
          ->join('profiles','profiles.user_id','=','users.id')
          ->select(['tenant_charges.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id','tenants.space_id','users.email','telephone','tenants.updated_at','tenants.created_at','users.id as user_id','tenant_charges.status as t_status','charge_name','effective_from','amount',
            'properties.id as pro_id'])
          ->where(['properties.provider_id'=>$p_id,'current_status'=>'Active']);

          }else{
            $p_id=Auth::User()->getProvider->id;
        $models=TenantCharges::join('tenants','tenants.id','=','tenant_charges.tenant_id')
          ->join('users','users.id','=','tenants.user_id')
           ->join('spaces','tenants.space_id','=','spaces.id')
          ->join('properties','properties.id','=','spaces.property_id')
          ->join('profiles','profiles.user_id','=','users.id')
          ->select(['tenant_charges.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id','tenants.space_id','users.email','telephone','tenants.updated_at','tenants.created_at','users.id as user_id','tenant_charges.status as t_status','charge_name','effective_from','amount','properties.id as pro_id'])
          ->where(['properties.provider_id'=>$p_id,'tenant_id'=>$tenant_id,'current_status'=>'Active']);
          }
        
         
           return Datatables::of($models)
           ->editColumn('name',function($model){
            list($a,$b)=explode(' ', $model->name);
             $view_url=url('/backend/tenant/view/'.$model->tenant_id);
            $unit_url=url('/backend/space/view/'.$model->space_id);

             $name=ucwords($a)." " .ucfirst($b);
             return '<a href="'.$view_url.'" >'.$name.'</a>';

           })
           ->editColumn('number',function($model){
            
            $unit_url=url('/backend/space/view/'.$model->space_id);
             return '<a href="'.$unit_url.'" >'.$model->number.'</a>';

           })

            ->editColumn('title',function($model){
            
            $unit_url=url('/backend/property/view/'.$model->pro_id);
             return '<a href="'.$unit_url.'" >'.$model->title.'</a>';

           })

             ->editColumn('amount',function($model){
            
            
             return '<span style="color:green">'.$model->amount.'</span>';

           })




           ->make(true);

     }


     public function paidPayments(){
       if(Entrust::hasRole("Admin") || Entrust::hasRole("Provider") ){
         $data['page_title']="Debit Payments";
         $data['tenant_id']=(isset($_GET['tenant_id']))? $_GET['tenant_id']:"All";
         return view('backend::tenants.debitlist',$data);



       }else{
        return view('forbidden');
       }
     }

     public function fetchDebits($tenant_id){


          if($tenant_id=="All"){
            $p_id=Auth::User()->getProvider->id;
        $models=TenantPayment::join('tenants','tenants.id','=','tenant_payments.tenant_id')
          ->join('users','users.id','=','tenants.user_id')
          ->join('spaces','tenants.space_id','=','spaces.id')
          ->join('properties','properties.id','=','spaces.property_id')
           ->join('sub_categories','sub_categories.id','=','properties.subcategory_id')
          ->join('profiles','profiles.user_id','=','users.id')
         ->select(['tenants.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id','tenants.space_id','users.email','telephone','tenants.updated_at','tenants.created_at','users.id as user_id','balance','debit','credit','reference_number','transaction_date','invoice_id','tenant_payments.created_at','sub_categories.name as sub_cat','tenant_payments.id as payment_id'])
          ->where('debit','>',0)
          ->where(['properties.provider_id'=>$p_id]);

          }else{
            $p_id=Auth::User()->getProvider->id;
        $models=TenantPayment::join('tenants','tenants.id','=','tenant_payments.tenant_id')
          ->join('users','users.id','=','tenants.user_id')
          ->join('spaces','tenants.space_id','=','spaces.id')

          ->join('properties','properties.id','=','spaces.property_id')
           ->join('sub_categories','sub_categories.id','=','properties.subcategory_id')
          ->join('profiles','profiles.user_id','=','users.id')
          ->select(['tenants.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id','tenants.space_id','users.email','telephone','tenants.updated_at','tenants.created_at','users.id as user_id','balance','debit','credit','reference_number','transaction_date','invoice_id','tenant_payments.created_at','sub_categories.name as sub_cat','tenant_payments.id as payment_id'])
          ->where('debit','>',0)
          ->where(['properties.provider_id'=>$p_id,'tenant_id'=>$tenant_id])
          ;
          }
        
         
           return Datatables::of($models)
            ->editColumn('reference_number',function($model){
            $url_to=url('/backend/tenant/payment/view/'.$model->payment_id);
            return '<span  data-url="'.$url_to.'" style="cursor:pointer;color:green"  title="View More Details"  class="reject-modal"
                                data-title="View Details" >'.$model->reference_number.'</span>';

           })
           ->editColumn('invoice_id',function($model){
            $invoices_url=url('/backend/invoice/view/'.$model->invoice_id);

            $model=Invoice::find($model->invoice_id);
              if($model){
                return '<a href="'.$invoices_url.'" >'.$model->invoice_number.'</a>';


                //$model->invoice_number;
              }else{
                return "Not Set";
              }



           })->make(true);





     }

     public function chargedPayments(){

        if(Entrust::hasRole("Admin") || Entrust::hasRole("Provider") ){
         $data['page_title']="Charges Made on Tenants";
         $data['tenant_id']=(isset($_GET['tenant_id']))? $_GET['tenant_id']:"All";
         return view('backend::tenants.creditlist',$data);



       }else{
        return view('forbidden');
       }

     }


     public function addBulkPayments()
     {
       if(Entrust::hasRole("Admin") || Entrust::hasRole("Provider") ){
         $data['page_title']="Perform Bulk Payment";
          $data['properties']=Property::where(['provider_id'=>auth::user()->getProvider->id])->get();
         
         return view('backend::tenants.create_bulk_payment',$data);



       }else{
        return view('forbidden');
       }

     }

     public function fetchCredits($tenant_id){

         if($tenant_id=="All"){
            $p_id=Auth::User()->getProvider->id;
        $models=TenantPayment::join('tenants','tenants.id','=','tenant_payments.tenant_id')
          ->join('users','users.id','=','tenants.user_id')
          ->join('spaces','tenants.space_id','=','spaces.id')
          ->join('properties','properties.id','=','spaces.property_id')
          ->join('sub_categories','sub_categories.id','=','properties.subcategory_id')
          ->join('profiles','profiles.user_id','=','users.id')
          ->select(['tenants.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id','tenants.space_id','users.email','telephone','tenants.updated_at','tenants.created_at','users.id as user_id','balance','debit','credit','reference_number','transaction_date','invoice_id','tenant_payments.created_at','sub_categories.name as sub_cat','tenant_payments.id as payment_id'])
          ->where('credit','>',0)
          ->where(['properties.provider_id'=>$p_id]);

          }else{
            $p_id=Auth::User()->getProvider->id;
        $models=TenantPayment::join('tenants','tenants.id','=','tenant_payments.tenant_id')
          ->join('users','users.id','=','tenants.user_id')
          ->join('spaces','tenants.space_id','=','spaces.id')
          ->join('sub_categories','sub_categories.id','=','properties.subcategory_id')
          ->join('properties','properties.id','=','spaces.property_id')
          ->join('profiles','profiles.user_id','=','users.id')
          ->select(['tenants.id as id','tenants.entry_date','users.name','spaces.number','properties.title','tenants.current_status','expected_end_date','tenants.id as tenant_id','tenants.space_id','users.email','telephone','tenants.updated_at','tenants.created_at','users.id as user_id','balance','debit','credit','reference_number','transaction_date','invoice_id','tenant_payments.created_at','sub_categories.name as sub_cat','tenant_payments.id as payment_id'])
          ->where('credit','>',0)
          ->where(['properties.provider_id'=>$p_id,'tenant_id'=>$tenant_id])
          ;
          }
        
         
           return Datatables::of($models)
           ->editColumn('reference_number',function($model){
            $url_to=url('/backend/tenant/payment/view/'.$model->payment_id);
            return '<span  data-url="'.$url_to.'" style="cursor:pointer;color:green"  title="View More Details"  class="reject-modal"
                                data-title="View Details" >'.$model->reference_number.'</span>';

           })->editColumn('invoice_id',function($model){
            $invoices_url=url('/backend/invoice/view/'.$model->invoice_id);

            $model=Invoice::find($model->invoice_id);
              if($model){
                return '<a href="'.$invoices_url.'" >'.$model->invoice_number.'</a>';


                //$model->invoice_number;
              }else{
                return "Not Set";
              }



           })->make(true);

     }

     public function createNewCategory(Request $request){
       $model=new Category();

         if($request->isMethod('post')){
          $data=$request->all();
          $model->name=$data['name'];
          $model->scope="local";
          $model->provider_id=Auth::User()->getProvider->id;
          $model->save();
          Session::flash("success_msg","Your Category Has Been Added Successfully");
          return redirect()->back();



         }
         $data['model']=$model;
         $data['url']=url("backend/category/add");

        return view('backend::tenants._addcat',$data);

    
     }


     public function getTenantReports($id)
     {

       $tenants=Tenant::join('spaces','spaces.id','=','tenants.space_id')->where(['property_id'=>$id])
       ->join('users','users.id','=','tenants.user_id')
       ->select('tenants.id','entry_date','expected_end_date','current_status','number','users.name')
       ->get();
       $property=Property::find($id);
        if(!$property){
          return view("not_found");
        }
        TenantPdf::generate($tenants,$property);

     }

     public function emailInvoice($id,Request $request)
     {
      $model=Invoice::find($id);
        if($model)
        {
          $data['url']=url()->current();
          $data['model']=$model;
           if($request->isMethod("post"))
           {
            $data=$request->all();
            $pdfPath=InvoicePDf::genareEmailPDF($model,$data['email']);
            Session::flash("success_msg","Invoice has Been Emailed to ".$data['email']." successfully");
            return redirect()->back();

             
           }



          return view('backend::tenants._emailInvoice',$data);

        }else{
          return "Resource Not Found";
        }

     }


     public  function RejectSubmittedPayments($id,Request $request)
     {
       
        if(Entrust::hasRole("Provider") || Entrust::hasRole("Agent"))
          {
            $model=SubmittedPayment::find($id);
            $data['model']=$model;
            $data['url']=url()->current();
             if($request->isMethod("post"))
             {
              $data=$request->all();
               try{

                $model->approve_status="Rejected";
                $model->reason=$data['reason'];
                $model->save();
                 
                          $messages="Dear ".$model->user->name." your payment with Ref No ".$model->ref_no." has been rejected because of the following reason ".$data['reason'];
                           $phone=str_replace('-','',$model->user->profile->telephone);
                          $subject="Rejected Payment #".$model->ref_no;
                           $email=$model->user->email;

                          Helper::sendSms($phone,$messages);
                          Helper::sendEmail($email,$messages,$subject);
                           $message=new Messaging();
                           $message->receiver_id=$model->user->id;
                           $message->sender_id=Auth::User()->id;
                           $message->subject="Rejected Payment #".$model->ref_no;
                           $message->content=$messages;
                           $message->flag="notification";
                           $message->key=strtoupper(str_random(8));
                           $message->save();
                           Session::flash('success_msg',"Payment Rejected Successfully and Tenant notified via email and phone");
                           return redirect()->back();
                }catch(\Exception $e)
               {
                 Helper::sendEmailToSupport($e);
                 Session::flash('danger_msg',"System Error Occured.System Admin notified on the error");
                  return redirect()->back();
               }
              


             }




              return view('tenants::tenants._reject',$data);

          

          }else{
            return 'access Denied.';
          }

     }

     public function ApproveSubmittedPayments($id)
     {
      $model=SubmittedPayment::where(['id'=>$id,'provider_id'=>auth::user()->getProvider->id])->first();
        if($model)
        {
           
           try{
            DB::beginTransaction();
          $tenant=Tenant::where(['space_id'=>$model->space_id,'current_status'=>'Active','user_id'=>$model->user_id])->first();
             if($tenant)
              {

                 $payment_data=array('provider_id'=>$model->provider_id,
                        'space_id'=>$model->space_id,
                        'invoice_id'=>$model->invoice_id,
                        'reference_number'=>strtoupper($model->ref_no),
                        'credit'=>0,
                        'debit'=>doubleval($model->amount_paid),
                        'description'=>"Peing Payment for Invoice Number".$model->invoice->number,
                        'payment_mode'=>$model->method,
                        'type'=>"Rent",
                        'transaction_date'=>date('Y-m-d',strtotime($model->transaction_date)),
                        'system_transaction_number'=>str_random(8),
                        'year'=>date('Y'),
                        'month'=>date('M'),
                        'fee_charges'=>0,
                        'tenant_id'=>$tenant->id,
                        );
                 $payment=$this->createnewPayment($payment_data,$model);
                   if($payment)
                   {
                    $model->approve_status="Approved";
                    $model->save();
                    DB::commit();
                    Session::flash("success_msg","Payment Approved successfully");
                    return redirect()->back();
                   }else{
                    Session::flash("success_msg","Payment Approved successfully");
                    return redirect()->back();

                   }
               


              }else{
                  Session::flash("danger_msg","Tenant Details not found.");
          return redirect()->back();
              }
              


           }catch(\Exception $e)
           {
            dd($e);
           }


        }else{
          Session::flash("danger_msg","Resource you are looking for is not found on this server.");
          return redirect()->back();
        }

     }

     public function createnewPayment($payment_data,$submitted_payment)
     {
     
       $model=TenantPayment::create($payment_data);
      if($model){

        $invoice=$model->invoice;
        $invoice->status="Paid";
        $invoice->save();
      
      }
      $user=$submitted_payment->user;
       $message=$body="Dear ".$user->name." we have receipt your payment  of ".$model->debit." ,for invoice ".$submitted_payment->invoice->invoice_number.". Your Receipt has been emailed to your for future reference";
       $message=new Messaging();
       $message->receiver_id=$user->id;
       $message->sender_id=Auth::User()->id;
       $message->subject="Payment Acknowledgement";
       $message->content=$body;
       $message->flag="message";
       $message->key=strtoupper(str_random(8));
       $message->save();

          return $model;
     }




}
