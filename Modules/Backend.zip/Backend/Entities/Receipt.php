<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;

class Receipt extends Model
{
    protected $fillable = [];
}
