<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;
use Modules\Backend\Entities\Space;
class TenantSummary extends Model
{
    protected $fillable = [];
    
         public function space(){
        return $this->belongsTo(Space::class);
    }
}
