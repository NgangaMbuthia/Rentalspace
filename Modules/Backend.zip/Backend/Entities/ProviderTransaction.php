<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;
use App\Mymodel;
class ProviderTransaction extends Mymodel
{
    protected $guarded = ['id'];
}
