<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;

class RepairItem extends Model
{
    protected $guarded = ['id'];
}
