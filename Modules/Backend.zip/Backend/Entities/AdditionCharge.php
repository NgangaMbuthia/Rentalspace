<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;
use App\Mymodel;
class AdditionCharge extends Mymodel
{
    protected $guarded = ['id'];
}
