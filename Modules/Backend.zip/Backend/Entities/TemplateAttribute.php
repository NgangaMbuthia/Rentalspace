<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;

class TemplateAttribute extends Model
{
	 protected $table="templates_attributes";
    protected $fillable = [];
}
