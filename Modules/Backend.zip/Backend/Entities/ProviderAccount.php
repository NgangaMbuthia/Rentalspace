<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;
use App\Mymodel;
class ProviderAccount extends Mymodel
{
    protected $fillable = [];
}
