<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;

class PropertyImage extends Model
{
    protected $guarded = ['id'];
}
