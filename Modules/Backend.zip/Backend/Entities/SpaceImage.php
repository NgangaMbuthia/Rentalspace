<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;

class SpaceImage extends Model
{
    protected $fillable = [];
}
