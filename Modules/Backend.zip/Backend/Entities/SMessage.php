<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;

class SMessage extends Model
{
	protected $table="smessages";
    protected $fillable = [];
}
