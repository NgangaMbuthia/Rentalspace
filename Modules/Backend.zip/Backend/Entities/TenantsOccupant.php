<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;

class TenantsOccupant extends Model
{
    protected $guarded = ['id'];
}
