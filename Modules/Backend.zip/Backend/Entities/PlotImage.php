<?php

namespace Modules\Backend\Entities;

use Illuminate\Database\Eloquent\Model;

class PlotImage extends Model
{
    protected $fillable = [];
}
